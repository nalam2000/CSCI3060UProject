How to run the code

From a Linux terminal:

- Change into the directory of the source code: ```cd ./src```
- Run the command: ```make```, this will compile all of the header and cpp files
- Run the program with the command:   ```./main```

